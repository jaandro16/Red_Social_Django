from django.urls import path
from . import views

urlpatterns = [
    path('signup', views.signup, name='accounts.signup'),
    path('account/login', views.login, name='accounts.login'),
    path('account/logout', views.logout, name='accounts.logout'),
    path('account/change_password', views.change_password, name='accounts.change_password'),
    path('account/edit_profile', views.edit_profile, name='accounts.edit_profile'),
]