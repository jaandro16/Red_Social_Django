from django.shortcuts import render
from django.contrib.auth import login as auth_login, authenticate, logout as auth_logout, update_session_auth_hash
from .forms import CustomUserCreationForm, CustomErrorList, CustomPasswordChangeForm, UserUpdateForm
from django.contrib import messages
from django.contrib.auth.forms import PasswordChangeForm
from django.shortcuts import redirect
from django.contrib.auth.decorators import login_required

# Create your views here.

@login_required
def logout(request):
    auth_logout(request)
    return redirect('home.index')


@login_required
def change_password(request):
    template_data = {'title': 'Change Password'}

    if request.method == 'POST':
        form = CustomPasswordChangeForm(user=request.user, data=request.POST)
        if form.is_valid():
            form.save()
            update_session_auth_hash(request, form.user)  # Mantiene la sesión activa tras cambiar la contraseña
            messages.success(request, 'Your password has been successfully updated.')
            return redirect('home.index')
        else:
            template_data['form'] = form
            return render(request, 'accounts/change_password.html', {'template_data': template_data})

    template_data['form'] = CustomPasswordChangeForm(user=request.user)
    return render(request, 'accounts/change_password.html', {'template_data': template_data})


@login_required
def edit_profile(request):
    template_data = {'title': 'Edit Profile'}

    if request.method == 'POST':
        form = UserUpdateForm(request.POST, instance=request.user)
        if form.is_valid():
            form.save()
            messages.success(request, 'Your profile has been updated successfully.')
            return redirect('accounts.edit_profile')
        else:
            template_data['form'] = form
            return render(request, 'accounts/edit_profile.html', {'template_data': template_data})

    template_data['form'] = UserUpdateForm(instance=request.user)
    return render(request, 'accounts/edit_profile.html', {'template_data': template_data})


def login(request):
    template_data = {}
    template_data['title'] = 'Login'
    if request.method == 'GET':
        return render(request, 'accounts/login.html', {'template_data': template_data})
    elif request.method == 'POST':
        user = authenticate(request, username = request.POST['username'], password = request.POST['password'])
        if user is None:
            template_data['error'] = 'The username or password is incorrect'
            return render(request, 'accounts/login.html', {'template_data': template_data})
        else:
            auth_login(request, user)
            return redirect('home.index')

def signup(request):
    template_data = {}
    template_data['title'] = 'Sign up'
    if request.method == 'GET':
        template_data['form'] = CustomUserCreationForm()
        return render(request, 'accounts/signup.html', {'template_data': template_data})
    elif request.method == 'POST':
        form = CustomUserCreationForm(request.POST, error_class=CustomErrorList)
        if form.is_valid():
            form.save()
            return redirect('accounts.login')
        else:
            template_data['form'] = form
            return render(request, 'accounts/signup.html', {'template_data': template_data})
        

